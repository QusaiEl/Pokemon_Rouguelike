World Generation - Qusai Elwazir - last updated: 2-7-23 4:00pm

Functionality:
This program allows for the traversal of a 401x401 array of pointers to map structs containing text terrain. Exits from each map connect to the roads of 
surrounding maps. Maps on the edge of the array will not have exits on their edge bordering sides. Map structs will only be created on visit. This program operates 
primarily using the move_to function which dynamically allocates memory for new map structs. This function is also used for general traversal
and will only allocate new memory when trying to traverse to a space containing a null pointer. pokemart and pokecenter will both be present in the starting map
as the user moves away from the starting map the frequency will decrease to 50% and then decrease linearly until 5% at a manhattan distance of around 200. Attempts to 
leave bounds will print errors and prompt the user for an alternate input.

input guide:
*only the first letter of inputs will be read by program, excluding coordinate inputs*
n - moves north 1 map
s - moves south 1 map
e - moves east 1 map
w - moves west 1 map
f - will promt the user for further input of 2 coordinate values in the range of x[-200,200] and y[-200,200] user must the input coordinates separated by a space
q - will end the program


