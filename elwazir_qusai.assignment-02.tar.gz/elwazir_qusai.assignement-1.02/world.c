#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define rock '%'
#define water '~'
#define road '#'
#define pokemon_center 'C'
#define pokemart 'M'
#define tall_grass ':'
#define clearing '.'
#define tree '^'
#define BUFFER 11

typedef struct map{
    char space[21][80];
    int n_exit, s_exit, e_exit, w_exit, dist;
}map;
int rand_in_range(int min, int max);
int is_valid_space(map *map, int row, int col);
int generate_region(map *map, int min_size, int max_size,int row_range_min, int row_range_max, int col_range_min, int col_range_max, char new_type);
int initialize_map(map *map);
int place_boarder(map *map);
int place_exits(map *map, int n, int s, int e, int w);
int place_tall_grass(map *map);
int place_water(map *map);
int place_mountains(map *map);
int place_store(map *map, char store);
int draw_roads(map *map);
int initialize_world();
int move_to(int row, int col);
int move_north();
int move_south();
int move_east();
int move_west();
int free_world();
void print_map(map *map);

map* world[401][401];
int world_pos_row;
int world_pos_col;

int main(int argc, char **argv){
    char user_str[BUFFER];
    int x = -1, y = -1;
    srand(time(NULL)); 
    initialize_world();
    print_map(world[world_pos_row][world_pos_col]);
    fgets(user_str, BUFFER, stdin);
    while(1){
        if(user_str[0]== 'n'){
            if(move_north() == -1){
                printf("desired space is out of bounds please select another space to traverse to:");
            } else {
                print_map(world[world_pos_row][world_pos_col]);
            }
        } else if(user_str[0] == 's'){
            if(move_south() == -1){
                printf("desired space is out of bounds please select another space to traverse to:");
            } else {
                print_map(world[world_pos_row][world_pos_col]);
            }
        } else if(user_str[0] == 'e'){
            if(move_east() == -1){
                printf("desired space is out of bounds please select another space to traverse to:");
            } else {
                print_map(world[world_pos_row][world_pos_col]);
            }
        } else if(user_str[0] == 'w'){
            if(move_west() == -1){
                printf("desired space is out of bounds please select another space to traverse to:");
            } else {
                print_map(world[world_pos_row][world_pos_col]);
            }
        } else if(user_str[0] == 'f'){ 
            printf("enter positon to fly to(X Y):");
            scanf("%d %d", &x, &y);
            fgets(user_str, BUFFER, stdin); // to hold back error
            if(move_to(200 - y, 200 + x) == -1){ 
                printf("desired space is out of bounds please enter another command:");
            }
            print_map(world[world_pos_row][world_pos_col]);
        } else if(user_str[0] == 'q'){
            free_world();
            exit(0);
        } else {
            printf("invalid input, please input: n for north, s for south, e for east, w for west, f to fly or q to quit:");
        }
        fgets(user_str, BUFFER, stdin);
    }
    
    return 0;
}

int rand_in_range(int min, int max){ 
    return (rand() % (max - min + 1)) + min;
}

// bount checking for region generation
int is_valid_space(map *map, int row, int col){ 
    if(row > 20 || row < 0 || col > 79 || col < 0 || map->space[row][col] == rock || map->space[row][col] == road){
        return -1;
    } else {
        return 0;
    }
}

// generates a generic biome
// @param map - map to generate on
// @param min_size - minimum generation steps
// @param max_size - maximum generation steps
// @param row_range, range of rows that genetation can be started on
int generate_region(map *map, int min_size, int max_size,int row_range_min, int row_range_max, int col_range_min, int col_range_max, char new_type){
    
    int row = rand_in_range(row_range_min, row_range_max); // starting positon
    int col = rand_in_range(col_range_min, col_range_max);
    int size = rand_in_range(min_size, max_size);
    int i;
    int rand_ns;
    int rand_ew;
    
    map->space[row][col] = new_type; 

    for(i = 0; i < size; ++i){

        if(rand() % 2 == 1){
            rand_ns = 1;    
        } else {
            rand_ns = -1; 
        }
         if(rand() % 2 == 1){
            rand_ew = 1;    
        } else {
            rand_ew = -1; 
        }

        row += rand_ns;
        col += rand_ew;

        if(is_valid_space(map, row, col) == 0){
            map->space[row][col] = new_type; 
        } 
        // step back into map
        if(is_valid_space(map, row + 1, col) == 0){
            map->space[row + 1][col] = new_type;
        } else {
            ++row;
            ++col;
        }
        if(is_valid_space(map, row - 1, col) == 0){
            map->space[row - 1][col] = new_type; 
        } else {
            ++row;
            --col;
        }
        if(is_valid_space(map, row, col + 1) == 0){
            map->space[row][col + 1] = new_type;
        } else {
            --row;
            ++col;
        }
        if(is_valid_space(map, row, col - 1) == 0){
            map->space[row][col - 1] = new_type; 
        } else {
            ++row;
            ++col;
        }
    }
    return 0;
}

int initialize_map(map *map){
    int i, j;
    for(i = 0; i < 21; ++i){
        for(j = 0; j < 80; ++j){
            map->space[i][j] = clearing;
        }
    }
    return 0;
}

// creates a boarder of boulders around the perimeter of the map
int place_boarder(map *map){
    int i;
    for(i = 0; i < 21; ++i){ // populates two cols on left and right most boarder
        map->space[i][0] = rock;
        map->space[i][79] = rock;
    }
    for(i = 1; i < 79; ++i){
        map->space[0][i] = rock;
        map->space[20][i] = rock;
    }
    return 0;
}

int place_exits(map *map, int n, int s, int e, int w){ // todo make -2 make no exit, - 1 make random exit, positive nums make param exit
    if(n == -1){map->n_exit = rand_in_range(1,78);} else {map->n_exit = n;}
    if(s == -1){map->s_exit = rand_in_range(1,78);} else {map->s_exit = s;}
    if(e == -1){map->e_exit = rand_in_range(1,19);} else {map->e_exit = e;}
    if(w == -1){map->w_exit = rand_in_range(1,19);} else {map->w_exit = w;}

    if(n != -2){map->space[0][map->n_exit] = road;} else {map->n_exit = -1;}
    if(s != -2){map->space[20][map->s_exit] = road;} else {map->s_exit = -1;}
    if(e != -2){map->space[map->e_exit][79] = road;} else {map->e_exit = -1;}
    if(w != -2){map->space[map->w_exit][0] = road;} else {map->w_exit = -1;}
    return 0;
}

int place_tall_grass(map *map){
    generate_region(map, 100, 200, 3, 11, 3, 40, tall_grass);
    generate_region(map, 100, 200, 10, 18, 42, 77, tall_grass);
    return 0;
}

int place_water(map *map){
    generate_region(map, 50, 100, 2, 18, 3, 77, water);
    generate_region(map, 50, 100, 3, 10, 3, 77, water);
    generate_region(map, 50, 100, 11, 18, 3, 77, water);
    return 0;
}


int place_mountains(map *map){
    generate_region(map, 110, 130, 3, 18, 3, 40, rock);
    generate_region(map, 110, 130, 3, 18, 42, 77, rock);
    return 0;
}

int place_store(map *map, char store){
    int i, j;
    for(i = 0; i < 21; ++i){
        for(j = 0; j < 80; ++j){
            if(map->space[i][j] == road && map->space[i][j - 5] == road && map->space[i][j + 5] == road){
                if(map->space[i - 1][j] != road && map->space[i - 1][j] != rock && map->space[i - 1][j] != pokemart &&  map->space[i - 1][j - 1] != pokemart){
                    map->space[i - 1][j] = store;
                    return 0;
                }
            }
        }
    }
    return -1;
}

int draw_roads(map *map){ 
    int row_pos = map->w_exit;
    int col_pos = 0;
    int rand_start_ns = rand_in_range(5,15);
    int rand_col = rand_in_range(30,60);
    int rand_row = rand_in_range(5,15);

    if(map->w_exit == -1){
        row_pos = rand_in_range(1, 19);
    }
    if(map->e_exit == -1){
        map->e_exit = rand_in_range(1, 19);
    }
    // e_exit to w_exit
    ++col_pos;
    map->space[row_pos][col_pos] = road;
   
    while(col_pos != 78){ 
        if(col_pos < rand_col){ // approaches a random point before approaching destination
            if(row_pos < rand_row){
                ++row_pos;
                map->space[row_pos][col_pos] = road;
            } else if(row_pos > rand_row){
                --row_pos;
                map->space[row_pos][col_pos] = road;
            }
            ++col_pos;
            map->space[row_pos][col_pos] = road;
           
            continue;
        }

        if(row_pos < map->e_exit){
            ++row_pos;
            map->space[row_pos][col_pos] = road;
        } else if(row_pos > map->e_exit){
            --row_pos;
            map->space[row_pos][col_pos] = road;
        }
        ++col_pos;
        map->space[row_pos][col_pos] = road;
    }

    // n_exit to s_exit
    row_pos = 0;
    col_pos = map->n_exit;

    if(map->n_exit == -1){
        col_pos = rand_in_range(1, 78);
    }
    if(map->s_exit == -1){
        map->s_exit = rand_in_range(1, 78);
    }

    ++row_pos;
    map->space[row_pos][col_pos] = road;

    while(row_pos != 19){ // working beeline algorithm
        if(row_pos == rand_start_ns){
            while(col_pos != map->s_exit){
                if(col_pos < map->s_exit){
                    ++col_pos;
                    map->space[row_pos][col_pos] = road;
                } else {
                    --col_pos;
                    map->space[row_pos][col_pos] = road;
                }
            }
        }

        if(col_pos < map->s_exit){
            ++col_pos;
            map->space[row_pos][col_pos] = road;
        } else if(col_pos > map->s_exit){
            --col_pos;
            map->space[row_pos][col_pos] = road;
        }
        ++row_pos;
        map->space[row_pos][col_pos] = road;
        
    }
    
    return 0;
}

int scater_trees(map *map){
    int i, j;
    for(i = 1; i < 19; ++i){
        for(j = 1; j < 78; ++j){
            if(rand() % 11 == 0){
                map->space[i][j] = tree;
            }
        }
    }
    return 0;
}

map* create_new_map(int n, int s, int e, int w, int i){
    map *new_map = malloc(sizeof(map));
    float store_spawn_chance;
    new_map->dist = abs(world_pos_col - 200) + abs(world_pos_row - 200) ;
    store_spawn_chance = (float) 100 * (((-45 * new_map->dist / 200)) + 50) / 100;
    if(store_spawn_chance < 5){
        store_spawn_chance = 5;
    }
    if(i == 0){
        store_spawn_chance = 100;
    }
    initialize_map(new_map);
    place_boarder(new_map);
    place_exits(new_map, n, s, e, w);
    scater_trees(new_map);
    place_mountains(new_map);
    place_water(new_map);
    place_tall_grass(new_map);
    draw_roads(new_map);
    if(store_spawn_chance >= rand() % 100){
        place_store(new_map, pokemart);
    }
    if(store_spawn_chance >= rand() % 100){
        place_store(new_map, pokemon_center);
    }
    return new_map;
}

int initialize_world(){
    int i, j;
    for(i = 0; i < 401; ++i){
        for(j = 0; j < 401; ++j){
            world[i][j] = NULL;
        }
    }
    world_pos_row = 200;
    world_pos_col = 200; 
    world[200][200] = create_new_map(-1, -1, -1, -1, 0);
    return 0;
}

int move_to(int row, int col){// bounds check
    int n = -1, s = -1, e = -1, w = -1;
    if(row < 0 || row >= 401 || col < 0 || col >= 401){
        return -1;
    }
    world_pos_row = row;
    world_pos_col = col;
    if(world[row][col] == NULL){
        if(row - 1 < 0){
            n = -2;
        } else if(world[row - 1][col] != NULL){ 
            n = world[row - 1][col]->s_exit;
        } 
        if(row + 1 > 400){
            s = -2;
        } else if(world[row + 1][col] != NULL){
            s = world[row + 1][col]->n_exit;
        }
        if(col + 1 > 400){
            e = -2;
        } else if(world[row][col + 1] != NULL){
            e = world[row][col + 1]->w_exit;
        }
        if(col - 1 < 0){
            w = -2;
        } else if(world[row][col - 1] != NULL){
            w = world[row][col - 1]->e_exit;
        }
        world[row][col] = create_new_map(n, s, e, w, -1);
    }
  
    return 0;
}

int move_north(){
    return move_to(world_pos_row - 1, world_pos_col);
}

int move_south(){
    return move_to(world_pos_row + 1, world_pos_col);
}

int move_east(){
    return move_to(world_pos_row, world_pos_col + 1);
}

int move_west(){
    return move_to(world_pos_row, world_pos_col - 1);
}

int free_world(){
    int i, j;
    for(i = 0; i < 401; ++i){
        for(j = 0; j < 401; ++j){
            free(world[i][j]);
        }
    }
    return 0;
}

void print_map(map *map){
    int i, j;
    for(i = 0; i < 21; ++i){
        printf("\n");
        for(j = 0; j < 80; ++j){
            printf("%c",map->space[i][j]);
        }
    }
    printf("\n");
    printf("Current Position: X(%d), Y(%d) and you are %d maps away from home!\nEnter a direction or f to fly to a new position or q to quit:",
        -(200 - world_pos_col), 200 - world_pos_row, world[world_pos_row][world_pos_col]->dist); 
}


