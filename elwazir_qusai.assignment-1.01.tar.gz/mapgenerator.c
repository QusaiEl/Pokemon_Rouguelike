#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define rock '%'
#define water '~'
#define road '#'
#define pokemon_center 'P'
#define pokemart 'C'
#define tall_grass ':'
#define clearing '.'
#define tree '^'

typedef struct map{
    char space[21][80];
    int n_exit, s_exit, e_exit, w_exit;
}map;

int rand_in_range(int min, int max){ 
    return (rand() % (max - min + 1)) + min;
}

// bount checking for region generation
int is_valid_space(map *map, int row, int col){ 
    if(row > 20 || row < 0 || col > 79 || col < 0 || map->space[row][col] == rock || map->space[row][col] == road){
        return -1;
    } else {
        return 0;
    }
}

// generates a generic biome
// @param map - map to generate on
// @param min_size - minimum generation steps
// @param max_size - maximum generation steps
// @param row_range, range of rows that genetation can be started on
int generate_region(map *map, int min_size, int max_size,int row_range_min, int row_range_max, int col_range_min, int col_range_max, char new_type){
    
    int row = rand_in_range(row_range_min, row_range_max); // starting positon
    int col = rand_in_range(col_range_min, col_range_max);
    int size = rand_in_range(min_size, max_size);
    int next_corner;
    int i;
    
    map->space[row][col] = new_type; 

    for(i = 0; i < size; ++i){
        next_corner = rand() % 3;
        if(next_corner == 0){
            --row;
            --col;
        } else if(next_corner == 1){
            --row;
            ++col;
        } else if(next_corner == 2){
            ++row;
            --col;
        } else {
            --row;
            --col;
        }
        if(is_valid_space(map, row, col) == 0){
            map->space[row][col] = new_type; 
        } 
        // step back into map
        if(is_valid_space(map, row + 1, col) == 0){
            map->space[row + 1][col] = new_type;
        } else {
            ++row;
            ++col;
        }
        if(is_valid_space(map, row - 1, col) == 0){
            map->space[row - 1][col] = new_type; 
        } else {
            ++row;
            --col;
        }
        if(is_valid_space(map, row, col + 1) == 0){
            map->space[row][col + 1] = new_type;
        } else {
            --row;
            ++col;
        }
        if(is_valid_space(map, row, col - 1) == 0){
            map->space[row][col - 1] = new_type; 
        } else {
            ++row;
            ++col;
        }
    }
    return 0;
}

int initialize_map(map *map){
    int i, j;
    for(i = 0; i < 21; ++i){
        for(j = 0; j < 80; ++j){
            map->space[i][j] = clearing;
        }
    }
    return 0;
}

// creates a boarder of boulders around the perimeter of the map
int place_boarder(map *map){
    int i;
    for(i = 0; i < 21; ++i){ // populates two cols on left and right most boarder
        map->space[i][0] = rock;
        map->space[i][79] = rock;
    }
    for(i = 1; i < 79; ++i){
        map->space[0][i] = rock;
        map->space[20][i] = rock;
    }
    return 0;
}

int place_exits(map *map){ 
    map->n_exit = rand_in_range(1,78);
    map->s_exit = rand_in_range(1,78);
    map->e_exit = rand_in_range(1,19);
    map->w_exit = rand_in_range(1,19);

    map->space[0][map->n_exit] = road;
    map->space[20][map->s_exit] = road;
    map->space[map->w_exit][0] = road;
    map->space[map->e_exit][79] = road;
    return 0;
}

int place_tall_grass(map *map){
    generate_region(map, 100, 200, 3, 18, 3, 40, tall_grass);
    generate_region(map, 100, 150, 3, 18, 42, 77, tall_grass);
    return 0;
}

int place_water(map *map){
    generate_region(map, 50, 100, 2, 18, 3, 77, water);
    generate_region(map, 50, 100, 3, 10, 3, 77, water);
    generate_region(map, 50, 100, 11, 18, 3, 77, water);
    return 0;
}


int place_mountains(map *map){
    generate_region(map, 110, 130, 3, 18, 3, 40, rock);
    generate_region(map, 110, 130, 3, 18, 42, 77, rock);
    return 0;
}


int place_stores(map *map){
    int i;
    int j;
    for(i = 0; i < 21; ++i){
        for(j = 0; j < 80; ++j){
            if(map->space[i][j] == road && map->space[i][j - 5] == road && map->space[i][j + 5] == road)
                if(map->space[i - 1][j] != road && map->space[i - 1][j] != rock && map->space[i - 1][j + 1] != road && map->space[i - 1][j + 1] != rock){
                    map->space[i - 1][j] = pokemart;
                    map->space[i - 1][j + 1] = pokemon_center;
                    return 0;
                }
        }
    }
    return -1;
}

int draw_roads(map *map){
    int row_pos = map->w_exit;
    int col_pos = 0;
    int rand_start_ns = rand_in_range(5,15);
    int rand_col = rand_in_range(30,60);
    int rand_row = rand_in_range(5,15);

    // e_exit to w_exit
    ++col_pos;
    map->space[row_pos][col_pos] = road;
   
    while(col_pos != 78){ 
        if(col_pos < rand_col){ // approaches a random point before approaching destination
            if(row_pos < rand_row){
                ++row_pos;
                map->space[row_pos][col_pos] = road;
            } else if(row_pos > rand_row){
                --row_pos;
                map->space[row_pos][col_pos] = road;
            }
            ++col_pos;
            map->space[row_pos][col_pos] = road;
           
            continue;
        }

        if(row_pos < map->e_exit){
            ++row_pos;
            map->space[row_pos][col_pos] = road;
        } else if(row_pos > map->e_exit){
            --row_pos;
            map->space[row_pos][col_pos] = road;
        }
        ++col_pos;
        map->space[row_pos][col_pos] = road;
        
    }

    // n_exit to s_exit
    row_pos = 0;
    col_pos = map->n_exit;
    ++row_pos;
    map->space[row_pos][col_pos] = road;

    while(row_pos != 19){ // working beeline algorithm
        if(row_pos == rand_start_ns){
            while(col_pos != map->s_exit){
                if(col_pos < map->s_exit){
                    ++col_pos;
                    map->space[row_pos][col_pos] = road;
                } else {
                    --col_pos;
                    map->space[row_pos][col_pos] = road;
                }
            }
        }

        if(col_pos < map->s_exit){
            ++col_pos;
            map->space[row_pos][col_pos] = road;
        } else if(col_pos > map->s_exit){
            --col_pos;
            map->space[row_pos][col_pos] = road;
        }
        ++row_pos;
        map->space[row_pos][col_pos] = road;
        
    }
    

    return 0;
}

map create_new_map(){
    map new_map;
    initialize_map(&new_map);
    place_boarder(&new_map);
    place_exits(&new_map);
    place_mountains(&new_map);
    place_water(&new_map);
    place_tall_grass(&new_map);
    draw_roads(&new_map);
    place_stores(&new_map);
    return new_map;
}

void print_map(map *map){
    int i, j;
    for(i = 0; i < 21; ++i){
        printf("\n");
        for(j = 0; j < 80; ++j){
            printf("%c",map->space[i][j]);
        }
    }
    printf("\n");
}

int main(){
    srand(time(NULL)); 
    map map = create_new_map();
    print_map(&map);
    return 0;
}