Path_Finding - Qusai Elwazir - last updated: Feb 20 9:00pm

Functionality:
This program outputs a string representation of a map struct created in 1.01 containing an '@' character representing the position of the player character. 
It also outputs two string representations of dist_map structs that contain the distance from each square to the player character mod 10 in a 2 digit representation 
for the rival npc type and the hiker npc type with given costs in 1.03 specifacation. This program uses dijkstras algorithm to find the best path from the player
character to every possible space with the movement costs of the given npc type.

The most relivant distinction between hiker and rival is that the hiker can move over mountians ('%') and trees ('^') and has lower movment costs over abnormal terrain
like tall grass. 

Output Guide:
The fist character block is the map in question. 
The second character block is the distance map related to the hiker. 
The third character block is the distace map related to the rival.