#define rock '%'
#define wall '`'
#define water '~'
#define road '#'
#define exit 'e'
#define pokemon_center 'C'
#define pokemart 'M'
#define tall_grass ':'
#define clearing '.'
#define tree '^'
#define rival 'r'
#define hiker 'h'
#define BUFFER 11

typedef struct map{
    char space[21][80];
    int n_exit, s_exit, e_exit, w_exit, dist;
    int PC_row, PC_col;
}map;
int rand_in_range(int min, int max);
int is_valid_space(map *map, int row, int col);
int generate_region(map *map, int min_size, int max_size,int row_range_min, int row_range_max, int col_range_min, int col_range_max, char new_type);
int initialize_map(map *map);
int place_boarder(map *map);
int place_exits(map *map, int n, int s, int e, int w);
int place_tall_grass(map *map);
int place_water(map *map);
int place_mountains(map *map);
int place_store(map *map, char store);
int draw_roads(map *map);
int initialize_world();
int move_to(int row, int col);
int move_north();
int move_south();
int move_east();
int move_west();
int free_world();
void print_map(map *map);

#define INF 9999

typedef struct dist_map{
    int space[21][80];
}dist_map;
typedef struct point{
    int row, col;
} point;

dist_map* make_dist_map(map* map, char t);

void find_dist(map* map, dist_map* dist, point dest, char t);

int movement_cost(char q, char t);

point* new_point(int r, int c);

void print_dist_map(dist_map* d);

typedef struct node{
    int priority;
    struct point* point;
    struct node* next;
} node;

int is_empty(node** head);
node* new_node(point* p, int prio);
point* peek(node** head);
point* pop(node** head);
int push(node** head, point* p, int prio);
int swap(node** s, node** o);
int decrease_prioirity(node** head, int r, int c, int p);