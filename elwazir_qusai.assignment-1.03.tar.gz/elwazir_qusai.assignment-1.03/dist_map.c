#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "dist_map.h"


map* world[401][401];
int world_pos_row;
int world_pos_col;

int main(int argc, char **argv){
    srand(time(NULL));
    initialize_world();
    dist_map* hiker_map = make_dist_map(world[world_pos_row][world_pos_col], hiker);
    dist_map* rival_map = make_dist_map(world[world_pos_row][world_pos_col], rival);
    print_map(world[world_pos_row][world_pos_col]);
    print_dist_map(hiker_map);
    printf("\n");
    print_dist_map(rival_map);
    printf("\n");
    return 0;
}

// int main(int argc, char **argv){
//     char user_str[BUFFER];
//     int x = -1, y = -1;
//     srand(time(NULL)); 
//     initialize_world();
//     print_map(world[world_pos_row][world_pos_col]);
//     fgets(user_str, BUFFER, stdin);
//     while(1){
//         if(user_str[0]== 'n'){
//             if(move_north() == -1){
//                 printf("desired space is out of bounds please select another space to traverse to:");
//             } else {
//                 print_map(world[world_pos_row][world_pos_col]);
//             }
//         } else if(user_str[0] == 's'){
//             if(move_south() == -1){
//                 printf("desired space is out of bounds please select another space to traverse to:");
//             } else {
//                 print_map(world[world_pos_row][world_pos_col]);
//             }
//         } else if(user_str[0] == 'e'){
//             if(move_east() == -1){
//                 printf("desired space is out of bounds please select another space to traverse to:");
//             } else {
//                 print_map(world[world_pos_row][world_pos_col]);
//             }
//         } else if(user_str[0] == 'w'){
//             if(move_west() == -1){
//                 printf("desired space is out of bounds please select another space to traverse to:");
//             } else {
//                 print_map(world[world_pos_row][world_pos_col]);
//             }
//         } else if(user_str[0] == 'f'){ 
//             printf("enter positon to fly to(X Y):");
//             scanf("%d %d", &x, &y);
//             fgets(user_str, BUFFER, stdin); // to hold back error
//             if(move_to(200 - y, 200 + x) == -1){ 
//                 printf("desired space is out of bounds please enter another command:");
//             }
//             print_map(world[world_pos_row][world_pos_col]);
//         } else if(user_str[0] == 'q'){
//             free_world();
//             exit(0);
//         } else {
//             printf("invalid input, please input: n for north, s for south, e for east, w for west, f to fly or q to quit:");
//         }
//         fgets(user_str, BUFFER, stdin);
//     }
    
//     return 0;
// }

int rand_in_range(int min, int max){ 
    return (rand() % (max - min + 1)) + min;
}

// bount checking for region generation
int is_valid_space(map *map, int row, int col){ 
    if(row > 20 || row < 0 || col > 79 || col < 0 || map->space[row][col] == wall || map->space[row][col] == road || map->space[row][col] == exit || map->space[row][col] == pokemart || map->space[row][col] == pokemon_center){
        return -1;
    } else {
        return 0;
    }
}

// generates a generic biome
// @param map - map to generate on
// @param min_size - minimum generation steps
// @param max_size - maximum generation steps
// @param row_range, range of rows that genetation can be started on
int generate_region(map *map, int min_size, int max_size,int row_range_min, int row_range_max, int col_range_min, int col_range_max, char new_type){
    
    int row = rand_in_range(row_range_min, row_range_max); // starting positon
    int col = rand_in_range(col_range_min, col_range_max);
    int size = rand_in_range(min_size, max_size);
    int i;
    int rand_ns;
    int rand_ew;
    
    map->space[row][col] = new_type; 

    for(i = 0; i < size; ++i){

        if(rand() % 2 == 1){
            rand_ns = 1;    
        } else {
            rand_ns = -1; 
        }
         if(rand() % 2 == 1){
            rand_ew = 1;    
        } else {
            rand_ew = -1; 
        }

        row += rand_ns;
        col += rand_ew;

        if(is_valid_space(map, row, col) == 0){
            map->space[row][col] = new_type; 
        } 
        // step back into map
        if(is_valid_space(map, row + 1, col) == 0){
            map->space[row + 1][col] = new_type;
        } else {
            ++row;
            ++col;
        }
        if(is_valid_space(map, row - 1, col) == 0){
            map->space[row - 1][col] = new_type; 
        } else {
            ++row;
            --col;
        }
        if(is_valid_space(map, row, col + 1) == 0){
            map->space[row][col + 1] = new_type;
        } else {
            --row;
            ++col;
        }
        if(is_valid_space(map, row, col - 1) == 0){
            map->space[row][col - 1] = new_type; 
        } else {
            ++row;
            ++col;
        }
    }
    return 0;
}

int initialize_map(map *map){
    int i, j;
    for(i = 0; i < 21; ++i){
        for(j = 0; j < 80; ++j){
            map->space[i][j] = clearing;
        }
    }
    return 0;
}

// creates a boarder of boulders around the perimeter of the map
int place_boarder(map *map){
    int i;
    for(i = 0; i < 21; ++i){ // populates two cols on left and right most boarder
        map->space[i][0] = wall;
        map->space[i][79] = wall;
    }
    for(i = 1; i < 79; ++i){
        map->space[0][i] = wall;
        map->space[20][i] = wall;
    }
    return 0;
}

int place_exits(map *map, int n, int s, int e, int w){ // todo make -2 make no exit, - 1 make random exit, positive nums make param exit
    if(n == -1){map->n_exit = rand_in_range(1,78);} else {map->n_exit = n;}
    if(s == -1){map->s_exit = rand_in_range(1,78);} else {map->s_exit = s;}
    if(e == -1){map->e_exit = rand_in_range(1,19);} else {map->e_exit = e;}
    if(w == -1){map->w_exit = rand_in_range(1,19);} else {map->w_exit = w;}

    if(n != -2){map->space[0][map->n_exit] = exit;} else {map->n_exit = -1;}
    if(s != -2){map->space[20][map->s_exit] = exit;} else {map->s_exit = -1;}
    if(e != -2){map->space[map->e_exit][79] = exit;} else {map->e_exit = -1;}
    if(w != -2){map->space[map->w_exit][0] = exit;} else {map->w_exit = -1;}
    return 0;
}

int place_tall_grass(map *map){
    generate_region(map, 100, 200, 3, 11, 3, 40, tall_grass);
    generate_region(map, 100, 200, 10, 18, 42, 77, tall_grass);
    return 0;
}

int place_water(map *map){
    generate_region(map, 50, 100, 2, 18, 3, 77, water);
    generate_region(map, 50, 100, 3, 10, 3, 77, water);
    generate_region(map, 50, 100, 11, 18, 3, 77, water);
    return 0;
}


int place_mountains(map *map){
    generate_region(map, 110, 130, 3, 18, 3, 40, rock);
    generate_region(map, 110, 130, 3, 18, 42, 77, rock);
    return 0;
}

int place_store(map *map, char store){
    int i, j;
    for(i = 0; i < 21; ++i){
        for(j = 0; j < 80; ++j){
            if(map->space[i][j] == road && map->space[i][j - 5] == road && map->space[i][j + 5] == road){
                if(map->space[i - 1][j] != exit && map->space[i - 1][j] != wall && map->space[i - 1][j] != pokemart &&  map->space[i - 1][j - 1] != pokemart){
                    map->space[i - 1][j] = store;
                    return 0;
                }
            }
        }
    }
    return -1;
}

int draw_roads(map *map){ 
    int row_pos = map->w_exit;
    int col_pos = 0;
    int rand_start_ns = rand_in_range(5,15);
    int rand_col = rand_in_range(30,60);
    int rand_row = rand_in_range(5,15);

    if(map->w_exit == -1){
        row_pos = rand_in_range(1, 19);
    }
    if(map->e_exit == -1){
        map->e_exit = rand_in_range(1, 19);
    }
    // e_exit to w_exit
    ++col_pos;
    map->space[row_pos][col_pos] = road;
   
    while(col_pos != 78){ 
        if(col_pos < rand_col){ // approaches a random point before approaching destination
            if(row_pos < rand_row){
                ++row_pos;
                map->space[row_pos][col_pos] = road;
            } else if(row_pos > rand_row){
                --row_pos;
                map->space[row_pos][col_pos] = road;
            }
            // for 1.03
            map->PC_row = row_pos;
            map->PC_col = col_pos;
            //
            ++col_pos;
            map->space[row_pos][col_pos] = road;
           
            continue;
        }
        
        if(row_pos < map->e_exit){
            ++row_pos;
            map->space[row_pos][col_pos] = road;
        } else if(row_pos > map->e_exit){
            --row_pos;
            map->space[row_pos][col_pos] = road;
        }
        ++col_pos;
        map->space[row_pos][col_pos] = road;
    }

    // n_exit to s_exit
    row_pos = 0;
    col_pos = map->n_exit;

    if(map->n_exit == -1){
        col_pos = rand_in_range(1, 78);
    }
    if(map->s_exit == -1){
        map->s_exit = rand_in_range(1, 78);
    }

    ++row_pos;
    map->space[row_pos][col_pos] = road;

    while(row_pos != 19){ // working beeline algorithm
        if(row_pos == rand_start_ns){
            while(col_pos != map->s_exit){
                if(col_pos < map->s_exit){
                    ++col_pos;
                    map->space[row_pos][col_pos] = road;
                } else {
                    --col_pos;
                    map->space[row_pos][col_pos] = road;
                }
            }
        }

        if(col_pos < map->s_exit){
            ++col_pos;
            map->space[row_pos][col_pos] = road;
        } else if(col_pos > map->s_exit){
            --col_pos;
            map->space[row_pos][col_pos] = road;
        }
        ++row_pos;
        map->space[row_pos][col_pos] = road;
        
    }
    
    return 0;
}

int scater_trees(map *map){
    int i, j;
    for(i = 1; i < 19; ++i){
        for(j = 1; j < 78; ++j){
            if(rand() % 11 == 0){
                map->space[i][j] = tree;
            }
        }
    }
    return 0;
}

map* create_new_map(int n, int s, int e, int w, int i){
    map *new_map = malloc(sizeof(map));
    float store_spawn_chance;
    new_map->dist = abs(world_pos_col - 200) + abs(world_pos_row - 200);
    store_spawn_chance = (float) 100 * (((-45 * new_map->dist / 200)) + 50) / 100;
    if(store_spawn_chance < 5){
        store_spawn_chance = 5;
    }
    if(i == 0){
        store_spawn_chance = 100;
    }
    initialize_map(new_map);
    place_boarder(new_map);
    place_exits(new_map, n, s, e, w);
    scater_trees(new_map);
    place_mountains(new_map);
    place_water(new_map);
    place_tall_grass(new_map);
    draw_roads(new_map);
    if(store_spawn_chance >= rand() % 100){
        place_store(new_map, pokemart);
    }
    if(store_spawn_chance >= rand() % 100){
        place_store(new_map, pokemon_center);
    }
    return new_map;
}

int initialize_world(){
    int i, j;
    for(i = 0; i < 401; ++i){
        for(j = 0; j < 401; ++j){
            world[i][j] = NULL;
        }
    }
    world_pos_row = 200;
    world_pos_col = 200; 
    world[200][200] = create_new_map(-1, -1, -1, -1, 0);
    return 0;
}

int move_to(int row, int col){// bounds check
    int n = -1, s = -1, e = -1, w = -1;
    if(row < 0 || row >= 401 || col < 0 || col >= 401){
        return -1;
    }
    world_pos_row = row;
    world_pos_col = col;
    if(world[row][col] == NULL){
        if(row - 1 < 0){
            n = -2;
        } else if(world[row - 1][col] != NULL){ 
            n = world[row - 1][col]->s_exit;
        } 
        if(row + 1 > 400){
            s = -2;
        } else if(world[row + 1][col] != NULL){
            s = world[row + 1][col]->n_exit;
        }
        if(col + 1 > 400){
            e = -2;
        } else if(world[row][col + 1] != NULL){
            e = world[row][col + 1]->w_exit;
        }
        if(col - 1 < 0){
            w = -2;
        } else if(world[row][col - 1] != NULL){
            w = world[row][col - 1]->e_exit;
        }
        world[row][col] = create_new_map(n, s, e, w, -1);
    }
  
    return 0;
}

int move_north(){
    return move_to(world_pos_row - 1, world_pos_col);
}

int move_south(){
    return move_to(world_pos_row + 1, world_pos_col);
}

int move_east(){
    return move_to(world_pos_row, world_pos_col + 1);
}

int move_west(){
    return move_to(world_pos_row, world_pos_col - 1);
}

int free_world(){
    int i, j;
    for(i = 0; i < 401; ++i){
        for(j = 0; j < 401; ++j){
            free(world[i][j]);
        }
    }
    return 0;
}

void print_map(map *map){
    int i, j;
    for(i = 0; i < 21; ++i){
        printf("\n");
        for(j = 0; j < 80; ++j){
            if(i == map->PC_row && j == map->PC_col){
                printf("@");
            }else if(map->space[i][j] == wall){
                printf("%c",rock);
            }else if(map->space[i][j] == exit){
                printf("%c", road);
            } else {
                printf("%c", map->space[i][j]);
            }
        }
    }
    // printf("\n");
    // printf("Current Position: X(%d), Y(%d) and you are %d maps away from home!\nEnter a direction or f to fly to a new position or q to quit:",
    //     -(200 - world_pos_col), 200 - world_pos_row, world[world_pos_row][world_pos_col]->dist); 
}

struct dist_map* make_dist_map(map* map, char t){
    dist_map* out_map = (dist_map*)malloc(sizeof(dist_map));
    point dest = {map->PC_row, map->PC_col};
    find_dist(map, out_map, dest, t);
    return out_map;
}

void find_dist(map* map, dist_map* dist, point dest, char t){
    int i,j;  // seg fault in here
    point* u = (point*)malloc(sizeof(point)); // visiting point
    int alt = INF;
    int visit[21][80]; // visitation map
    node* Q = (node*)malloc(sizeof(node));
    Q = new_node(new_point(dest.row, dest.col), 0); // prio queue
    visit[dest.row][dest.col] = -1;
    dist->space[dest.row][dest.col] = 0;

    for(i = 0; i < 21; ++i){ // distance map
        for(j = 0; j < 80; ++j){
            if(i == dest.row && j == dest.col){
                continue;
            } else {
                dist->space[i][j] = INF;
            }
            visit[i][j] = -1;
            push(&Q, new_point(i, j), dist->space[i][j]); // 
        }
    } 

    while(is_empty(&Q) != 0){
       u = pop(&Q);
       for(i = -1; i < 2; ++i){
           for(j = -1; j < 2; ++j){ // indext through surrounding
                if(i == 0 && j == 0){
                    continue;
                }
                if(u->row + i >= 0 && u->row + i < 20 && u->col + j >= 0 && u->col + j < 80 && visit[u->row + i][u->col + j] == -1){
                    alt = dist->space[u->row][u->col] + movement_cost(map->space[u->row + i][u->col + j], t);
                    if(alt < dist->space[u->row + i][u->col + j]){ 
                        dist->space[u->row + i][u->col + j] = alt;
                        decrease_prioirity(&Q, u->row + i, u->col + j, alt); 
                    }
                }
           }
        }
        visit[u->row][u->col] = 0; // mark as visited
    }
    free(u);
    return; // can break out when full dij alg is complete or after u->dest is visited
}

int movement_cost(char q, char t){
    if(q == wall){
        if(t == rival){
            return INF;
        } else {
            return INF;
        }
    } else if(q == rock){
         if(t == rival){
            return INF;
        } else {
            return 15;
        }
    } else if(q == water){
         if(t == rival){
            return INF;
        } else {
            return INF;
        }
    } else if(q == road){
         if(t == rival){
            return 10;
        } else {
            return 10;
        }
    } else if(q == pokemon_center){
         if(t == rival){
            return 50;
        } else {
            return 50;
        }
    } else if(q == pokemart){
         if(t == rival){
            return 50;
        } else {
            return 50;
        }
    } else if(q == tall_grass){
        if(t == rival){
            return 20;
        } else {
            return 15;
        }
    } else if(q == clearing){
         if(t == rival){
            return 10;
        } else {
            return 10;
        }
    } else if(q == tree) {
        if(t == rival){
            return INF;
        } else {
            return 15;
        }
    }
    return INF;
}

struct point* new_point(int r, int c){
    point* temp = (point*)malloc(sizeof(point));
    temp->row = r;
    temp->col = c;
    return temp;
}

void print_dist_map(dist_map* d){
    int i, j;
    for(i = 0; i < 21; ++i){
        printf("\n");
        for(j = 0; j < 80; ++j){
            if(d->space[i][j] == 9999){
                printf("   ");
            } else {
                printf("%02d ", (d->space[i][j] % 100));
            }
        }
    }
}

// prio queue
int is_empty(node** head){
    if((*head) == NULL){
        return 0;
    } else {
        return 1;
    }
}

struct node* new_node(point* p, int priority){ 
    node* temp = (node*)malloc(sizeof(node));
    temp->point = p;
    temp->priority = priority;
    temp->next = NULL;
    return temp;
}

struct point* peek(node** head){
    return (*head)->point;
}

struct point* pop(node** head){
    if((*head) == NULL){
        return NULL;
    }
    point* d = (*head)->point;
    node* temp = (*head);
    (*head) = (*head)->next;
    free(temp);
    return d;
}

int push(node** head, point* p, int priority){ 
    node* start = (*head);
    node* temp = new_node(p, priority);

    if((*head)->priority > priority){
        temp->next = (*head);
        (*head) = temp;
    } else {
         while (start->next != NULL && start->next->priority < priority) { 
            start = start->next; 
        } 
        temp->next = start->next; 
        start->next = temp; 
    }
    return 0;
}

int decrease_prioirity(node** head, int r, int c, int p){ 
    node* curr = (*head);
    node* prev;
    
    if(curr != NULL && curr->point->row == r && curr->point->col == c){
        (*head) = curr->next;
        free(curr);
        return 0;
    }

    while(curr != NULL && (curr->point->row != r || curr->point->col != c)){
        prev = curr;
        curr = curr->next;
    }

    if(curr == NULL){
        return -1;
    }

    prev->next = curr->next;
    free(curr);

    push(head, new_point(r, c), p);
    return 0;
}





